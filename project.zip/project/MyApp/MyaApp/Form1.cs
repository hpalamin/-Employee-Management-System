﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MyaApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-I32PIMD;Initial Catalog=AnDB;Trusted_connection=True");
            SqlCommand cmd = new SqlCommand("INSERT INTO Department VALUES('"+txtDepartmentName.Text+"')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            lblMsg.Text = "Data inserted successfully!!!";
            LoadGrid();
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void LoadGrid()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-I32PIMD;Initial Catalog=AnDB;Trusted_connection=True");
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Department", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
    }
}
