﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MyaApp
{
    public partial class FormDep : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-I32PIMD;Initial Catalog=AnDB;Trusted_connection=True");
        public FormDep()
        {
            InitializeComponent();
        }

        private void FormDep_Load(object sender, EventArgs e)
        {
            LoadCombo();
            LoadGrid();
        }
        private void LoadCombo()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT DepartmentId,DepartmentName FROM Department", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cmbDepartment.DataSource = dt;
            cmbDepartment.DisplayMember = "DepartmentName";
            cmbDepartment.ValueMember = "DepartmentId";
            con.Close();
        }

        private void LoadGrid()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("SELECT e=E.id, E.name as 'Name',E.dob as 'Date of Birth',E.email as 'Email',E.gender as 'gender',E.NID as 'Nid',E.EmpAddress as 'EpmAddress',D.DepartmentName as 'Department' FROM Employee E INNER JOIN Department D ON E.DepartmentId=D.DepartmentId", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO Employee VALUES('" +txtName.Text + "','" + txtEmail.Text + "','" + dateTimePicker1.Value+ "','" + cmbGender.SelectedItem.ToString()+ "','" + txtContact.Text + "','" + txtNid.Text + "','" + txtAddress.Text + "'," + cmbDepartment.SelectedValue + ")", con);
            con.Open();
            cmd.ExecuteNonQuery();
            lblMsg.Text = "Data inserted successfully!!!";
            
            con.Close();
            LoadGrid();
            ClearAll();

        }
        private void ClearAll()
        {
            txtName.Clear();
            txtEmail.Clear();
            txtContact.Clear();
            txtName.Clear();
            txtNid.Clear();
            txtAddress.Clear();
            cmbDepartment.SelectedIndex = -1;
            cmbGender.SelectedIndex = -1;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "UPDATE Employee SET name='" + txtName.Text + "',email='" + txtEmail.Text + "',dob='" + dateTimePicker1.Value + "',gender='" + cmbGender.SelectedItem.ToString() + "',contactNo='" + txtContact.Text + "',Nid='" + txtNid.Text + "',Address='" + txtAddress.Text + "',DepartmentId='" + cmbDepartment.SelectedValue + "' WHERE id=" + txtSearch.Text + "";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            lblMsg.Text = "Data Updated successfully!!";
            LoadGrid();
            ClearAll();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "DELETE FROM Employee WHERE id=" + txtSearch.Text + "";
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            lblMsg.Text = "Data Deleted successfully!!";
            LoadGrid();
            ClearAll();
        }
    }
}
