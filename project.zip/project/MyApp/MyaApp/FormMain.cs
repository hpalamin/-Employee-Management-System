﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyaApp
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void departmentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormDep frm = new FormDep();
            frm.Show();
        }

        private void frmEmpAddEditToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmEmpAddEdit frm = new FrmEmpAddEdit();
            frm.Show();
        }

        private void employeeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Add_Information frm = new Add_Information();
            frm.Show();
        }
    }
}
